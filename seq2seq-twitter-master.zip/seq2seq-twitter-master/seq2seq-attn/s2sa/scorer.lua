require 's2sa.scorers.bleu'
require 's2sa.scorers.gleu'

scorers = {
  bleu=get_bleu,
  gleu=get_gleu
}
